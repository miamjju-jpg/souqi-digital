from pathlib import Path
import runpy

project_dir = Path(__file__).resolve().parent
app_file = project_dir / "app.py"
if not app_file.is_file():
    raise FileNotFoundError("لم يتم العثور على app.py داخل مجلد المشروع")
print("SOUQI DIGITAL STARTER V3")
print("Project folder:", project_dir)
print("Templates folder exists:", (project_dir / "templates").is_dir())
print("Home template exists:", (project_dir / "templates" / "index.html").is_file())
runpy.run_path(str(app_file), run_name="__main__")
