import os, sqlite3, secrets, hashlib, hmac, time
from pathlib import Path
from functools import wraps
from flask import Flask, g, render_template, request, redirect, url_for, session, flash, abort, send_file, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

def find_project_dir():
    candidates = [Path.cwd(), Path(__file__).resolve().parent]
    storage_roots = [
        Path("/storage/emulated/0/Download"),
        Path("/storage/emulated/0/Documents"),
        Path("/storage/emulated/0"),
        Path.home(),
    ]
    for root in candidates:
        if (root / "templates" / "index.html").is_file() and (root / "static").is_dir():
            return root.resolve()
    seen = set()
    for parent in storage_roots:
        try:
            parent = parent.resolve()
            if parent in seen or not parent.exists():
                continue
            seen.add(parent)
            for index_file in parent.rglob("templates/index.html"):
                root = index_file.parent.parent
                if (root / "static").is_dir() and (root / "app.py").is_file():
                    return root.resolve()
        except (OSError, PermissionError, RuntimeError):
            pass
    raise RuntimeError(
        "لم يتم العثور على ملفات واجهة المتجر. فك ضغط ZIP كاملًا، ثم شغّل app.py الموجود داخل مجلد souqi_marketplace، "
        "مع إبقاء مجلدي templates وstatic بجواره."
    )

BASE_DIR = find_project_dir()
DB_PATH = Path(os.environ.get("SOUQI_DB", BASE_DIR / "souqi.sqlite3"))
UPLOAD_DIR = Path(os.environ.get("SOUQI_UPLOADS", BASE_DIR / "uploads"))
PRODUCT_DIR = BASE_DIR / "products"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
PRODUCT_DIR.mkdir(parents=True, exist_ok=True)

app = Flask(__name__, template_folder=str(BASE_DIR / "templates"), static_folder=str(BASE_DIR / "static"))
app.secret_key = os.environ.get("SOUQI_SECRET_KEY") or secrets.token_hex(32)
app.config["MAX_CONTENT_LENGTH"] = 40 * 1024 * 1024
ALLOWED_EXTENSIONS = {"pdf", "zip", "xlsx", "csv", "docx", "pptx", "txt", "md", "png", "jpg", "jpeg"}
CATEGORIES = ["الذكاء الاصطناعي", "قوالب الأعمال", "كتب وأدلة", "تصميم", "تعليم", "برامج وأدوات"]
ADMIN_EMAIL = os.environ.get("SOUQI_ADMIN_EMAIL", "").strip().lower()
if not ADMIN_EMAIL:
    try:
        ADMIN_EMAIL = (BASE_DIR / "admin_email.txt").read_text(encoding="utf-8").strip().lower()
    except OSError:
        ADMIN_EMAIL = ""

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys=ON")
    return g.db

@app.teardown_appcontext
def close_db(_=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("PRAGMA foreign_keys=ON")
    conn.executescript("""
    CREATE TABLE IF NOT EXISTS users(
      id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS products(
      id INTEGER PRIMARY KEY AUTOINCREMENT, seller_id INTEGER, title TEXT NOT NULL, category TEXT NOT NULL,
      description TEXT NOT NULL, price_cents INTEGER NOT NULL CHECK(price_cents>=0), currency TEXT NOT NULL DEFAULT 'EGP',
      filename TEXT, original_filename TEXT, emoji TEXT NOT NULL DEFAULT '📦', featured INTEGER NOT NULL DEFAULT 0,
      active INTEGER NOT NULL DEFAULT 1, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(seller_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS orders(
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL, total_cents INTEGER NOT NULL,
      currency TEXT NOT NULL DEFAULT 'EGP', status TEXT NOT NULL DEFAULT 'pending',
      payment_reference TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY(user_id) REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS order_items(
      id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER NOT NULL, product_id INTEGER NOT NULL,
      title_snapshot TEXT NOT NULL, price_cents INTEGER NOT NULL, filename_snapshot TEXT,
      FOREIGN KEY(order_id) REFERENCES orders(id), FOREIGN KEY(product_id) REFERENCES products(id)
    );
    """)
    conn.commit()
    # Seed a clearly labelled starter product. Its deliverable is generated in this project.
    count = conn.execute("SELECT COUNT(*) FROM products").fetchone()[0]
    if count == 0:
        kit = PRODUCT_DIR / "arabic_ai_business_starter_kit.zip"
        if kit.exists():
            conn.execute("""INSERT INTO products
              (seller_id,title,category,description,price_cents,currency,filename,original_filename,emoji,featured)
              VALUES(NULL,?,?,?,?,?,?,?,?,1)""",
              ("حزمة تشغيل مشروع صغير بالذكاء الاصطناعي", "الذكاء الاصطناعي",
               "حزمة عربية عملية تضم قوالب خدمة العملاء، وصناعة المحتوى، ومتابعة العملاء، وخطة إطلاق لمدة 7 أيام. ملفات قابلة للتعديل وليست وعدًا بأرباح.",
               19900, "EGP", kit.name, "arabic_ai_business_starter_kit.zip", "🤖"))
    conn.commit()
    conn.close()

def current_user():
    uid = session.get("user_id")
    if not uid:
        return None
    return db().execute("SELECT id,name,email FROM users WHERE id=?", (uid,)).fetchone()

@app.context_processor
def inject_globals():
    return {"current_user": current_user(), "categories": CATEGORIES, "admin_email": ADMIN_EMAIL}

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("user_id"):
            flash("سجّل الدخول أولًا لإكمال هذه الخطوة.", "warning")
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapped

def admin_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        u = current_user()
        if not u or not ADMIN_EMAIL or u["email"].lower() != ADMIN_EMAIL:
            abort(403)
        return fn(*args, **kwargs)
    return wrapped

def money(cents, currency="EGP"):
    return f"{cents/100:,.2f} {'ج.م' if currency == 'EGP' else currency}"

@app.template_filter("money")
def money_filter(cents, currency="EGP"):
    return money(cents, currency)

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/")
def index():
    q = request.args.get("q", "").strip()[:100]
    category = request.args.get("category", "").strip()
    sort = request.args.get("sort", "featured")
    sql = "SELECT p.*, COALESCE(u.name,'سوقي الرقمي') AS seller_name FROM products p LEFT JOIN users u ON u.id=p.seller_id WHERE p.active=1"
    args = []
    if q:
        sql += " AND (p.title LIKE ? OR p.description LIKE ? OR p.category LIKE ?)"
        args.extend([f"%{q}%"]*3)
    if category in CATEGORIES:
        sql += " AND p.category=?"
        args.append(category)
    order = {"price_low":"p.price_cents ASC", "price_high":"p.price_cents DESC", "newest":"p.created_at DESC"}.get(sort, "p.featured DESC, p.created_at DESC")
    sql += " ORDER BY " + order
    products = db().execute(sql, args).fetchall()
    return render_template("index.html", products=products, q=q, selected_category=category, sort=sort)

@app.route("/product/<int:product_id>")
def product_detail(product_id):
    p = db().execute("""SELECT p.*, COALESCE(u.name,'سوقي الرقمي') AS seller_name
                        FROM products p LEFT JOIN users u ON u.id=p.seller_id
                        WHERE p.id=? AND p.active=1""", (product_id,)).fetchone()
    if not p: abort(404)
    return render_template("product.html", p=p)

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        name = request.form.get("name","").strip()[:80]
        email = request.form.get("email","").strip().lower()[:190]
        password = request.form.get("password","")
        if not name or "@" not in email or len(password) < 8:
            flash("أدخل اسمًا وبريدًا صحيحًا وكلمة مرور من 8 أحرف على الأقل.", "danger")
        else:
            try:
                cur = db().execute("INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
                                   (name,email,generate_password_hash(password)))
                db().commit()
                session["user_id"] = cur.lastrowid
                flash("تم إنشاء الحساب. يمكنك الآن تجربة الشراء أو إضافة منتج.", "success")
                return redirect(url_for("index"))
            except sqlite3.IntegrityError:
                flash("هذا البريد مسجل بالفعل.", "danger")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        email=request.form.get("email","").strip().lower()
        password=request.form.get("password","")
        user=db().execute("SELECT * FROM users WHERE email=?",(email,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"]=user["id"]
            flash("أهلًا بعودتك.", "success")
            return redirect(request.args.get("next") or url_for("index"))
        flash("بيانات الدخول غير صحيحة.", "danger")
    return render_template("auth.html", mode="login")

@app.route("/logout", methods=["POST"])
def logout():
    session.clear()
    flash("تم تسجيل الخروج.", "success")
    return redirect(url_for("index"))

@app.route("/sell", methods=["GET","POST"])
@login_required
def sell():
    if request.method == "POST":
        title=request.form.get("title","").strip()[:120]
        category=request.form.get("category","")
        description=request.form.get("description","").strip()[:3000]
        try:
            price=int(round(float(request.form.get("price","0"))*100))
        except ValueError:
            price=-1
        emoji=request.form.get("emoji","📦")[:8]
        file=request.files.get("file")
        if not title or category not in CATEGORIES or not description or price < 0 or price > 100000000:
            flash("راجع الاسم والتصنيف والوصف والسعر.", "danger")
        elif file and file.filename and not allowed_file(file.filename):
            flash("امتداد الملف غير مسموح. الأنواع المتاحة: PDF, ZIP, XLSX, CSV, DOCX, PPTX, TXT, MD, PNG, JPG.", "danger")
        else:
            stored = None
            original = None
            if file and file.filename:
                original=secure_filename(file.filename)[:180] or "download"
                stored=f"{secrets.token_hex(16)}_{original}"
                file.save(UPLOAD_DIR / stored)
            db().execute("""INSERT INTO products(seller_id,title,category,description,price_cents,currency,filename,original_filename,emoji)
                            VALUES(?,?,?,?,?,'EGP',?,?,?)""",
                         (session["user_id"],title,category,description,price,stored,original,emoji))
            db().commit()
            flash("تم إرسال المنتج إلى السوق. في هذه النسخة يظهر مباشرة؛ راجع الحقوق وجودة الملف قبل النشر العام.", "success")
            return redirect(url_for("index"))
    return render_template("sell.html")

@app.route("/checkout", methods=["POST"])
@login_required
def checkout():
    ids = request.form.getlist("product_id")
    # This MVP creates a pending order only. It does not pretend to collect payment.
    unique_ids=[]
    for value in ids:
        try:
            pid=int(value)
            if pid not in unique_ids: unique_ids.append(pid)
        except ValueError: pass
    if not unique_ids:
        flash("سلة الشراء فارغة.", "warning")
        return redirect(url_for("index"))
    marks=",".join("?" for _ in unique_ids)
    items=db().execute(f"SELECT * FROM products WHERE active=1 AND id IN ({marks})", unique_ids).fetchall()
    if len(items)!=len(unique_ids):
        flash("بعض المنتجات لم تعد متاحة. حدّث السلة.", "danger")
        return redirect(url_for("index"))
    total=sum(x["price_cents"] for x in items)
    cur=db().execute("INSERT INTO orders(user_id,total_cents,status) VALUES(?,?,'pending')",(session["user_id"],total))
    oid=cur.lastrowid
    for p in items:
        db().execute("INSERT INTO order_items(order_id,product_id,title_snapshot,price_cents,filename_snapshot) VALUES(?,?,?,?,?)",
                     (oid,p["id"],p["title"],p["price_cents"],p["filename"]))
    db().commit()
    return redirect(url_for("order_detail", order_id=oid))

@app.route("/orders/<int:order_id>")
@login_required
def order_detail(order_id):
    order=db().execute("SELECT * FROM orders WHERE id=? AND user_id=?",(order_id,session["user_id"])).fetchone()
    if not order: abort(404)
    items=db().execute("SELECT * FROM order_items WHERE order_id=?",(order_id,)).fetchall()
    return render_template("order.html", order=order, items=items)

@app.route("/my-orders")
@login_required
def my_orders():
    orders=db().execute("SELECT * FROM orders WHERE user_id=? ORDER BY id DESC",(session["user_id"],)).fetchall()
    return render_template("orders.html", orders=orders)

@app.route("/download/<int:order_item_id>")
@login_required
def download(order_item_id):
    row=db().execute("""SELECT oi.*,o.status,o.user_id FROM order_items oi JOIN orders o ON o.id=oi.order_id
                        WHERE oi.id=? AND o.user_id=?""",(order_item_id,session["user_id"])).fetchone()
    if not row or row["status"] != "paid":
        abort(403)
    filename=row["filename_snapshot"]
    if not filename: abort(404)
    path=UPLOAD_DIR / filename
    if not path.exists(): path=PRODUCT_DIR / filename
    if not path.exists(): abort(404)
    return send_file(path, as_attachment=True, download_name=filename.split("_",1)[-1])

@app.route("/admin")
@login_required
@admin_required
def admin():
    orders=db().execute("""SELECT o.*,u.name,u.email FROM orders o JOIN users u ON u.id=o.user_id ORDER BY o.id DESC LIMIT 100""").fetchall()
    products=db().execute("""SELECT p.*,COALESCE(u.name,'سوقي الرقمي') seller_name FROM products p LEFT JOIN users u ON u.id=p.seller_id ORDER BY p.id DESC""").fetchall()
    return render_template("admin.html", orders=orders, products=products)

@app.route("/admin/order/<int:order_id>/mark-paid", methods=["POST"])
@login_required
@admin_required
def mark_paid(order_id):
    db().execute("UPDATE orders SET status='paid',payment_reference=? WHERE id=?",
                 (request.form.get("reference","manual-review")[:120],order_id))
    db().commit()
    flash("تم تحديث حالة الطلب يدويًا. استخدم ذلك بعد التحقق من الدفع خارج التطبيق فقط.", "success")
    return redirect(url_for("admin"))

@app.route("/admin/product/<int:product_id>/toggle", methods=["POST"])
@login_required
@admin_required
def toggle_product(product_id):
    db().execute("UPDATE products SET active=CASE active WHEN 1 THEN 0 ELSE 1 END WHERE id=?",(product_id,))
    db().commit()
    return redirect(url_for("admin"))

@app.errorhandler(403)
def forbidden(_):
    return render_template("error.html", code=403, message="ليس لديك صلاحية للوصول إلى هذه الصفحة."), 403

@app.errorhandler(404)
def not_found(_):
    return render_template("error.html", code=404, message="الصفحة أو المنتج غير موجود."), 404

@app.errorhandler(413)
def too_large(_):
    return render_template("error.html", code=413, message="حجم الملف أكبر من الحد المسموح (40 ميجابايت)."), 413

with app.app_context():
    init_db()

if __name__ == "__main__":
    app.run(host=os.environ.get("HOST","127.0.0.1"), port=int(os.environ.get("PORT","5000")), debug=False)
